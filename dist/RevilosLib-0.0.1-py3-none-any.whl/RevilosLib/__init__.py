from RevilosLib.CLI import *
from RevilosLib.IDgenerator import *